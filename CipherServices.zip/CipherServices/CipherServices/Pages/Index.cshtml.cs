﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using CipherServices.Services;
using CipherServices.Data;
using CipherServices.Models;

namespace CipherServices.Pages
{
    public class IndexModel : PageModel
    {
        public Dictionary<string, string> Secrets { get; set; }
        [BindProperty]
        public Message NewMessage { get; set; }

        private readonly MessageContext _messageContext;
        private readonly IDecrypter _decrypter;
        private readonly IEncrypter _encrypter;

        public IndexModel(MessageContext messageContext, IDecrypter decrypter, IEncrypter encrypter)
        {
            _messageContext = messageContext;
            _decrypter = decrypter;
            _encrypter = encrypter;
        }

        public async Task<IActionResult> OnGet()
        {
            await LoadSecretsAsync(_decrypter, _messageContext);
            return Page();
        }

        private async Task LoadSecretsAsync(IDecrypter decrypter, MessageContext context)
        {
            Secrets = new Dictionary<string, string>();
            var messages = await context.Messages.ToListAsync();

            foreach (Message m in messages)
            {
                Secrets.TryAdd(m.Text, decrypter.Decrypt(m.Text));
            }
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (ModelState.IsValid)
            {
                String m = NewMessage.Text.Trim().ToLower();
                String newMessage = _encrypter.Encrypt(m);

                Message message = new Message { Text = newMessage };
                _messageContext.Add(message);
                await _messageContext.SaveChangesAsync();

            }
            else
            {
                await LoadSecretsAsync(_decrypter, _messageContext);
                return Page();
            }
            return RedirectToPage("/Index");
        }
    }
}
